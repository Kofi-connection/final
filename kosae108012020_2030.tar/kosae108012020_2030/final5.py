import shutil

source= "FINALinstruction"
destination= "FINALpython/copies/"
destinationc= "FINALc/copies/"
path=shutil.copy(source,destination)


#pathc=shutil.copy(source, destinationc)
